const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = 8080;

// MIME types
const mimeTypes = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpg',
    '.gif': 'image/gif',
    '.ico': 'image/x-icon',
    '.svg': 'image/svg+xml',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf',
    '.eot': 'application/vnd.ms-fontobject'
};

const server = http.createServer((req, res) => {
    let pathname = url.parse(req.url).pathname;
    const method = req.method;
    
    // Enable CORS for API requests
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
    
    // Handle preflight OPTIONS requests
    if (method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }
    
    // API Routes
    if (pathname.startsWith('/api/')) {
        handleAPIRequest(req, res, pathname);
        return;
    }
    
    // Default to admin panel
    if (pathname === '/') {
        pathname = '/admin-panel.html';
    }
    
    const filePath = path.join(__dirname, pathname);
    
    // Security check - prevent directory traversal
    if (!filePath.startsWith(__dirname)) {
        res.writeHead(403);
        res.end('Access forbidden');
        return;
    }
    
    fs.readFile(filePath, (err, data) => {
        if (err) {
            if (err.code === 'ENOENT') {
                res.writeHead(404);
                res.end('File not found');
            } else {
                res.writeHead(500);
                res.end('Server error');
            }
            return;
        }
        
        const ext = path.extname(pathname);
        const mimeType = mimeTypes[ext] || 'text/plain';
        
        res.writeHead(200, {
            'Content-Type': mimeType,
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            'Cache-Control': 'no-cache, no-store, must-revalidate'
        });
        
        res.end(data);
    });
});

// API Request Handler
function handleAPIRequest(req, res, pathname) {
    const method = req.method;
    
    switch (pathname) {
        case '/api/health':
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
                status: 'healthy',
                service: 'TINI Admin Panel',
                version: '4.1.0',
                timestamp: new Date().toISOString(),
                uptime: process.uptime()
            }));
            break;
            
        case '/api/status':
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
                status: 'online',
                server: 'admin-panel',
                port: PORT,
                memory: process.memoryUsage(),
                timestamp: new Date().toISOString()
            }));
            break;
            
        case '/api/ping':
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
                ping: 'pong',
                timestamp: new Date().toISOString(),
                server: 'TINI-Admin-Panel'
            }));
            break;
            
        case '/api/auth/validate':
            if (method === 'POST') {
                handleAuthValidation(req, res);
            } else {
                res.writeHead(405);
                res.end('Method not allowed');
            }
            break;
            
        default:
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'API endpoint not found' }));
    }
}

// Authentication validation handler
function handleAuthValidation(req, res) {
    let body = '';
    
    req.on('data', chunk => {
        body += chunk.toString();
    });
    
    req.on('end', () => {
        try {
            const data = JSON.parse(body);
            const { username, deviceId } = data;
            
            // Basic validation
            if (!username || !deviceId) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({
                    success: false,
                    error: 'Missing username or deviceId'
                }));
                return;
            }
            
            // Validate using TINI validation patterns
            const isValidUsername = username.length >= 3 && username.length <= 50;
            const isValidDeviceId = /^[a-zA-Z0-9-]{8,36}$/.test(deviceId);
            
            if (isValidUsername && isValidDeviceId) {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({
                    success: true,
                    message: 'Authentication successful',
                    user: {
                        username: username,
                        deviceId: deviceId,
                        timestamp: new Date().toISOString()
                    }
                }));
            } else {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({
                    success: false,
                    error: 'Invalid username or device ID format'
                }));
            }
            
        } catch (error) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
                success: false,
                error: 'Invalid JSON data'
            }));
        }
    });
}

server.listen(PORT, () => {
    console.log('========================================');
    console.log('   TINI ADMIN PANEL - NODE.JS SERVER');
    console.log('========================================');
    console.log('');
    console.log(`🚀 Server running on: http://localhost:${PORT}`);
    console.log(`📱 Admin Panel: http://localhost:${PORT}/admin-panel.html`);
    console.log('');
    console.log('Press Ctrl+C to stop the server');
    console.log('========================================');
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n\n👋 Server shutting down gracefully...');
    server.close(() => {
        console.log('✅ Server closed successfully');
        process.exit(0);
    });
});
